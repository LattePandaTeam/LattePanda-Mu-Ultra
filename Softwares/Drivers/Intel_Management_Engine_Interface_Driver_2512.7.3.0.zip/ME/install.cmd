@echo off
cd /d "%~dp0"

pnputil /add-driver *.inf /subdirs /install

exit 0