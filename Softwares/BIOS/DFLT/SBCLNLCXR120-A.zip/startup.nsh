@echo -off 
for %a run (0 15 1) 
  if exist fs%a:\SBCLNLCXR120-A then  
     fs%a:  
     cd SBCLNLCXR120-A 
     cls  
     BIOS.nsh 
  endif  
endfor  
